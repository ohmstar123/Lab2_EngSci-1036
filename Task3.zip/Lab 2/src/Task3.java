public class Task3 {
    public static void main(String[] args) {

        String name = "Joe Mahoney";
        int age = 26;
        double annualPay = 100000.0;

        System.out.println("My name is " + name + ", my age is " + age + " and \nI hope to earn " + annualPay + " per year.");
    }
}
