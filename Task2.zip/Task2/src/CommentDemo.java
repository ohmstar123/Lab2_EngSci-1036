/**
 * This program opens a java doc
 *
 * @author (Ohm)
 * @version (Java 16)
 */
public class CommentDemo
{
    /**
     * This method with both recieve and return a value
     *
     * @param  x   a sample parameter for a method
     * @return     x square
     */
    public int squareFunction(int x)
    {
        // returns the square of x
        return x * x;

    }
}
